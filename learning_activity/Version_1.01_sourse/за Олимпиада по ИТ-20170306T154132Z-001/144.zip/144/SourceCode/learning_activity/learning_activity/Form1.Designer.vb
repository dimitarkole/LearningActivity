﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ВъведиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.УроциToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.УчителиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ПрофилиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.КласовеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ПреподавателиНаКласоветеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОценкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОценкиToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОтсъствияToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РъчноToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.СправкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЗаЕднаГодинаToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СреденУспехПоПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОтсъствияПоПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СреденУспехПоКласовеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОтсъствияПоКласовеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СравняванеНаДвеГодиниToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.УспехПоПаралелкиЗа2ГодиниToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.УспехПоКласовеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ИсторияПрезГодинитеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ПаралелкитеПрезГодинитеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.КласоветеПрезГодинитеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ПомощToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ПомощToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЗаПрограматаToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ВъведиToolStripMenuItem, Me.СправкиToolStripMenuItem, Me.ПомощToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(742, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.TabStop = True
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ВъведиToolStripMenuItem
        '
        Me.ВъведиToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.УроциToolStripMenuItem, Me.УчителиToolStripMenuItem, Me.ПрофилиToolStripMenuItem, Me.КласовеToolStripMenuItem, Me.ПреподавателиНаКласоветеToolStripMenuItem, Me.ОценкиToolStripMenuItem, Me.ОценкиToolStripMenuItem1, Me.ОтсъствияToolStripMenuItem})
        Me.ВъведиToolStripMenuItem.Name = "ВъведиToolStripMenuItem"
        Me.ВъведиToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.ВъведиToolStripMenuItem.Text = "Данни"
        '
        'УроциToolStripMenuItem
        '
        Me.УроциToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem})
        Me.УроциToolStripMenuItem.Name = "УроциToolStripMenuItem"
        Me.УроциToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.УроциToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.УроциToolStripMenuItem.Text = "Предмети"
        '
        'РъчноToolStripMenuItem
        '
        Me.РъчноToolStripMenuItem.Name = "РъчноToolStripMenuItem"
        Me.РъчноToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem.Text = "ръчно"
        Me.РъчноToolStripMenuItem.Visible = False
        '
        'УчителиToolStripMenuItem
        '
        Me.УчителиToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem1})
        Me.УчителиToolStripMenuItem.Name = "УчителиToolStripMenuItem"
        Me.УчителиToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.УчителиToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.УчителиToolStripMenuItem.Text = "Учители"
        '
        'РъчноToolStripMenuItem1
        '
        Me.РъчноToolStripMenuItem1.Name = "РъчноToolStripMenuItem1"
        Me.РъчноToolStripMenuItem1.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem1.Text = "ръчно"
        Me.РъчноToolStripMenuItem1.Visible = False
        '
        'ПрофилиToolStripMenuItem
        '
        Me.ПрофилиToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem2})
        Me.ПрофилиToolStripMenuItem.Name = "ПрофилиToolStripMenuItem"
        Me.ПрофилиToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ПрофилиToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.ПрофилиToolStripMenuItem.Text = "Профили"
        '
        'РъчноToolStripMenuItem2
        '
        Me.РъчноToolStripMenuItem2.Name = "РъчноToolStripMenuItem2"
        Me.РъчноToolStripMenuItem2.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem2.Text = "ръчно"
        Me.РъчноToolStripMenuItem2.Visible = False
        '
        'КласовеToolStripMenuItem
        '
        Me.КласовеToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem3})
        Me.КласовеToolStripMenuItem.Name = "КласовеToolStripMenuItem"
        Me.КласовеToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.КласовеToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.КласовеToolStripMenuItem.Text = "Класове"
        '
        'РъчноToolStripMenuItem3
        '
        Me.РъчноToolStripMenuItem3.Name = "РъчноToolStripMenuItem3"
        Me.РъчноToolStripMenuItem3.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem3.Text = "ръчно"
        Me.РъчноToolStripMenuItem3.Visible = False
        '
        'ПреподавателиНаКласоветеToolStripMenuItem
        '
        Me.ПреподавателиНаКласоветеToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem4})
        Me.ПреподавателиНаКласоветеToolStripMenuItem.Name = "ПреподавателиНаКласоветеToolStripMenuItem"
        Me.ПреподавателиНаКласоветеToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.ПреподавателиНаКласоветеToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.ПреподавателиНаКласоветеToolStripMenuItem.Text = "Преподаватели на класовете"
        '
        'РъчноToolStripMenuItem4
        '
        Me.РъчноToolStripMenuItem4.Name = "РъчноToolStripMenuItem4"
        Me.РъчноToolStripMenuItem4.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem4.Text = "ръчно"
        Me.РъчноToolStripMenuItem4.Visible = False
        '
        'ОценкиToolStripMenuItem
        '
        Me.ОценкиToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem5})
        Me.ОценкиToolStripMenuItem.Name = "ОценкиToolStripMenuItem"
        Me.ОценкиToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ОценкиToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.ОценкиToolStripMenuItem.Text = "Видове оценки"
        '
        'РъчноToolStripMenuItem5
        '
        Me.РъчноToolStripMenuItem5.Name = "РъчноToolStripMenuItem5"
        Me.РъчноToolStripMenuItem5.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem5.Text = "ръчно"
        Me.РъчноToolStripMenuItem5.Visible = False
        '
        'ОценкиToolStripMenuItem1
        '
        Me.ОценкиToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem6})
        Me.ОценкиToolStripMenuItem1.Name = "ОценкиToolStripMenuItem1"
        Me.ОценкиToolStripMenuItem1.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
                    Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ОценкиToolStripMenuItem1.Size = New System.Drawing.Size(270, 22)
        Me.ОценкиToolStripMenuItem1.Text = "Оценки"
        '
        'РъчноToolStripMenuItem6
        '
        Me.РъчноToolStripMenuItem6.Name = "РъчноToolStripMenuItem6"
        Me.РъчноToolStripMenuItem6.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem6.Text = "ръчно"
        Me.РъчноToolStripMenuItem6.Visible = False
        '
        'ОтсъствияToolStripMenuItem
        '
        Me.ОтсъствияToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.РъчноToolStripMenuItem7})
        Me.ОтсъствияToolStripMenuItem.Name = "ОтсъствияToolStripMenuItem"
        Me.ОтсъствияToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.ОтсъствияToolStripMenuItem.Size = New System.Drawing.Size(270, 22)
        Me.ОтсъствияToolStripMenuItem.Text = "Отсъствия"
        '
        'РъчноToolStripMenuItem7
        '
        Me.РъчноToolStripMenuItem7.Name = "РъчноToolStripMenuItem7"
        Me.РъчноToolStripMenuItem7.Size = New System.Drawing.Size(109, 22)
        Me.РъчноToolStripMenuItem7.Text = "ръчно"
        Me.РъчноToolStripMenuItem7.Visible = False
        '
        'СправкиToolStripMenuItem
        '
        Me.СправкиToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ЗаЕднаГодинаToolStripMenuItem, Me.СравняванеНаДвеГодиниToolStripMenuItem, Me.ИсторияПрезГодинитеToolStripMenuItem})
        Me.СправкиToolStripMenuItem.Name = "СправкиToolStripMenuItem"
        Me.СправкиToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.СправкиToolStripMenuItem.Text = "Справки"
        '
        'ЗаЕднаГодинаToolStripMenuItem
        '
        Me.ЗаЕднаГодинаToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.СреденУспехПоПаралелкиToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem, Me.ОтсъствияПоПаралелкиToolStripMenuItem, Me.СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem, Me.СреденУспехПоКласовеToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem, Me.ОтсъствияПоКласовеToolStripMenuItem, Me.СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem})
        Me.ЗаЕднаГодинаToolStripMenuItem.Name = "ЗаЕднаГодинаToolStripMenuItem"
        Me.ЗаЕднаГодинаToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ЗаЕднаГодинаToolStripMenuItem.Text = "За една година"
        '
        'СреденУспехПоПаралелкиToolStripMenuItem
        '
        Me.СреденУспехПоПаралелкиToolStripMenuItem.Name = "СреденУспехПоПаралелкиToolStripMenuItem"
        Me.СреденУспехПоПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СреденУспехПоПаралелкиToolStripMenuItem.Text = "Среден успех по паралелки"
        '
        'СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem.Text = "Съотношение на оценките по брой (Всички паралелки)"
        '
        'ОтсъствияПоПаралелкиToolStripMenuItem
        '
        Me.ОтсъствияПоПаралелкиToolStripMenuItem.Name = "ОтсъствияПоПаралелкиToolStripMenuItem"
        Me.ОтсъствияПоПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.ОтсъствияПоПаралелкиToolStripMenuItem.Text = "Отсъствия по паралелки"
        '
        'СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem
        '
        Me.СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem.Name = "СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem"
        Me.СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem.Text = "Съотношение на отсъствията по брой (Всички паралелки)"
        '
        'СреденУспехПоКласовеToolStripMenuItem
        '
        Me.СреденУспехПоКласовеToolStripMenuItem.Name = "СреденУспехПоКласовеToolStripMenuItem"
        Me.СреденУспехПоКласовеToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СреденУспехПоКласовеToolStripMenuItem.Text = "Среден успех по класове"
        '
        'СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Text = "Съотношение на оценките по брой (Паралелките от един клас)"
        '
        'ОтсъствияПоКласовеToolStripMenuItem
        '
        Me.ОтсъствияПоКласовеToolStripMenuItem.Name = "ОтсъствияПоКласовеToolStripMenuItem"
        Me.ОтсъствияПоКласовеToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.ОтсъствияПоКласовеToolStripMenuItem.Text = "Отсъствия по класове"
        '
        'СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem
        '
        Me.СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Name = "СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem"
        Me.СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Size = New System.Drawing.Size(440, 22)
        Me.СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem.Text = "Съотношение на отсъствията по брой (Паралелките от един клас)"
        '
        'СравняванеНаДвеГодиниToolStripMenuItem
        '
        Me.СравняванеНаДвеГодиниToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.УспехПоПаралелкиЗа2ГодиниToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem, Me.УспехПоКласовеToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem})
        Me.СравняванеНаДвеГодиниToolStripMenuItem.Name = "СравняванеНаДвеГодиниToolStripMenuItem"
        Me.СравняванеНаДвеГодиниToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.СравняванеНаДвеГодиниToolStripMenuItem.Text = "Сравняване на две години"
        '
        'УспехПоПаралелкиЗа2ГодиниToolStripMenuItem
        '
        Me.УспехПоПаралелкиЗа2ГодиниToolStripMenuItem.Name = "УспехПоПаралелкиЗа2ГодиниToolStripMenuItem"
        Me.УспехПоПаралелкиЗа2ГодиниToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.УспехПоПаралелкиЗа2ГодиниToolStripMenuItem.Text = "Успех по паралелки"
        '
        'СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem.Text = "Съотношение на оценките по брой  (Всички паралелки)"
        '
        'УспехПоКласовеToolStripMenuItem
        '
        Me.УспехПоКласовеToolStripMenuItem.Name = "УспехПоКласовеToolStripMenuItem"
        Me.УспехПоКласовеToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.УспехПоКласовеToolStripMenuItem.Text = "Успех по класове"
        '
        'СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem.Text = "Съотношение на оценките по брой (Паралелките от един клас)"
        '
        'ИсторияПрезГодинитеToolStripMenuItem
        '
        Me.ИсторияПрезГодинитеToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ПаралелкитеПрезГодинитеToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem, Me.КласоветеПрезГодинитеToolStripMenuItem, Me.СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem})
        Me.ИсторияПрезГодинитеToolStripMenuItem.Name = "ИсторияПрезГодинитеToolStripMenuItem"
        Me.ИсторияПрезГодинитеToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ИсторияПрезГодинитеToolStripMenuItem.Text = "История през годините"
        '
        'ПаралелкитеПрезГодинитеToolStripMenuItem
        '
        Me.ПаралелкитеПрезГодинитеToolStripMenuItem.Name = "ПаралелкитеПрезГодинитеToolStripMenuItem"
        Me.ПаралелкитеПрезГодинитеToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.ПаралелкитеПрезГодинитеToolStripMenuItem.Text = "Успех по паралелките"
        '
        'СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem.Text = "Съотношение на оценките по брой (Всички паралелки)"
        '
        'КласоветеПрезГодинитеToolStripMenuItem
        '
        Me.КласоветеПрезГодинитеToolStripMenuItem.Name = "КласоветеПрезГодинитеToolStripMenuItem"
        Me.КласоветеПрезГодинитеToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.КласоветеПрезГодинитеToolStripMenuItem.Text = "Успех по класовете"
        '
        'СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem
        '
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem.Name = "СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem"
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem.Size = New System.Drawing.Size(425, 22)
        Me.СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem.Text = "Съотношение на оценките по брой (Паралелките от един клас)"
        '
        'ПомощToolStripMenuItem
        '
        Me.ПомощToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ПомощToolStripMenuItem1, Me.ЗаПрограматаToolStripMenuItem})
        Me.ПомощToolStripMenuItem.Name = "ПомощToolStripMenuItem"
        Me.ПомощToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.ПомощToolStripMenuItem.Text = "Помощ"
        '
        'ПомощToolStripMenuItem1
        '
        Me.ПомощToolStripMenuItem1.Name = "ПомощToolStripMenuItem1"
        Me.ПомощToolStripMenuItem1.Size = New System.Drawing.Size(155, 22)
        Me.ПомощToolStripMenuItem1.Text = "Помощ"
        '
        'ЗаПрограматаToolStripMenuItem
        '
        Me.ЗаПрограматаToolStripMenuItem.Name = "ЗаПрограматаToolStripMenuItem"
        Me.ЗаПрограматаToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.ЗаПрограматаToolStripMenuItem.Text = "За програмата"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(662, 384)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "F1- help"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "helpHTML\HelpHTML.chm"
        Me.HelpProvider1.Tag = "F1"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(718, 321)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(742, 406)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.HelpButton = True
        Me.HelpProvider1.SetHelpKeyword(Me, "Начало")
        Me.HelpProvider1.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.HelpProvider1.SetHelpString(Me, "Начало")
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.HelpProvider1.SetShowHelp(Me, True)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Анализ на учебната дейност"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ВъведиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents УроциToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents УчителиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ПрофилиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents КласовеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ПреподавателиНаКласоветеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ОценкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ОценкиToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ОтсъствияToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents РъчноToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СправкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents ПомощToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ПомощToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ЗаПрограматаToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ЗаЕднаГодинаToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СреденУспехПоПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройВсичкиПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ОтсъствияПоПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОтсъствиятаПоБройВсичкиПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СреденУспехПоКласовеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройПаралелкитеОтЕдинКласToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ОтсъствияПоКласовеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОтсъствиятаПоБройПаралелкитеОтЕдинКласToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СравняванеНаДвеГодиниToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents УспехПоПаралелкиЗа2ГодиниToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройЗа2ГодиниВсичкиПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents УспехПоКласовеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройЗа2ГодиниПаралелкитеОтЕдинКласToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ИсторияПрезГодинитеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ПаралелкитеПрезГодинитеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройПрезГодинитеВсичкиПаралелкиToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents КласоветеПрезГодинитеToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents СъотношениеНаОценкитеПоБройПрезГодинитеПаралелкитеОтЕдинКласToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
